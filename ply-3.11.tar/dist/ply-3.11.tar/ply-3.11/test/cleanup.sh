#!/bin/sh

rm -rf *~ *.pyc *.pyo *.dif *.out __pycache__

